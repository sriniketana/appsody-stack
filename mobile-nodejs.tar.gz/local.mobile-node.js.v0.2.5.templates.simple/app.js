

var express = require('express');
var passport = require('passport-mfp-token-validation').Passport;
var mfpStrategy = require('passport-mfp-token-validation').Strategy;

passport.use(new mfpStrategy({
    authServerUrl: 'http://localhost:9080/mfp/api',
    confClientID: 'test',
    confClientPass: 'test',
    analytics: {
        onpremise: {
            url: 'http://localhost:9080/analytics-service/rest/v3',
            username: 'admin',
            password: 'admin'
        }
    }
}));

var app = express();
app.use(passport.initialize());

app.get('/getItems', passport.authenticate('mobilefirst-strategy', {
        session: false,
        scope: 'registeredClient'
    }),
    function(req, res) {
      var tasklist = {"total_rows":5,"offset":0,"rows":[
{"id":"3d296f7ab1d2b553579de17f8b3755f5","key":"3d296f7ab1d2b553579de17f8b3755f5","value":{"rev":"2-10bcb38fda22ec5a4dd637472622a9bb"},"doc":{"_id":"3d296f7ab1d2b553579de17f8b3755f5","_rev":"2-10bcb38fda22ec5a4dd637472622a9bb","name":"1210 - Television Service","description":"Deliver LED Television Model 128ca24","thumbnail":"https://dl.dropboxusercontent.com/s/7e46n49i9majycb/television.jpg"}},
{"id":"7450c452645a5e3008bb95f3fe05c9f1","key":"7450c452645a5e3008bb95f3fe05c9f1","value":{"rev":"2-f29d15b7296cecdbb0e1c383cb8c9f11"},"doc":{"_id":"7450c452645a5e3008bb95f3fe05c9f1","_rev":"2-f29d15b7296cecdbb0e1c383cb8c9f11","name":"1267 - Freezer Repair","description":"Deep Freezer is not functioning","thumbnail":"https://dl.dropboxusercontent.com/s/8of8ovsdezudrmt/fridge.png"}},
{"id":"9efe19648239df9a8d5814eb776cc1cb","key":"9efe19648239df9a8d5814eb776cc1cb","value":{"rev":"3-a41e6558647ad52d02072c72d6a78d14"},"doc":{"_id":"9efe19648239df9a8d5814eb776cc1cb","_rev":"3-a41e6558647ad52d02072c72d6a78d14","name":"1210 - Microwave Oven Service","description":"Annual Maintenance Service of the Oven","thumbnail":"https://dl.dropboxusercontent.com/s/giecmukb71q2nqb/micro-oven.jpg"}},
{"id":"c417cc1850f4b9199e993a6a734b9c91","key":"c417cc1850f4b9199e993a6a734b9c91","value":{"rev":"1-26ef9a7f0c70019e3216bd55dd3e0faa"},"doc":{"_id":"c417cc1850f4b9199e993a6a734b9c91","_rev":"1-26ef9a7f0c70019e3216bd55dd3e0faa","name":"1267 - Freezer AMT","description":"AMT Service for Freezer","thumbnail":"https://dl.dropboxusercontent.com/s/8of8ovsdezudrmt/fridge.png"}},
{"id":"f43934836aaa017913fdfff60e99b973","key":"f43934836aaa017913fdfff60e99b973","value":{"rev":"2-64e3595ad703451038ee4d67858b3257"},"doc":{"_id":"f43934836aaa017913fdfff60e99b973","_rev":"2-64e3595ad703451038ee4d67858b3257","name":"1928 - Washing Machine Repair","description":"Drum is not spinning","thumbnail":"https://dl.dropboxusercontent.com/s/5iv3dr9dl36ac5i/washing-machine.png"}}
]} ;

        res.send(tasklist);
    });
    
 
module.exports.app = app;
